# BBIM502 - Assessment 1
# Task 7 - Data Structures: List
# Census Data Collection System


def get_valid_age(prompt="Enter Age: "):
    """Validates user age input."""
    while True:
        try:
            age = int(input(prompt))
            if 0 < age <= 125:
                return age
            print("Error: Please enter a valid age between 1 and 125.\n")
        except ValueError:
            print("Error: Age must be a whole number.\n")


def display_census_list(user_list, title="Current Census User List"):
    """Helper function to print formatted list."""
    print(f"\n--- {title} ---")
    if not user_list:
        print("(List is empty)")
        return
    for idx, item in enumerate(user_list):
        print(f" Index {idx}: Name = {item[0]:<15} | Age = {item[1]}")


def main():
    print("=" * 65)
    print("           CENSUS DATA COLLECTION SYSTEM (LISTS)")
    print("=" * 65)

    # 1. Accept initial user records into a list
    census_users = []

    print("\n[Step 1] Initial Data Entry:")
    while True:
        name = input("Enter Full Name: ").strip()
        while not name:
            print("Name cannot be empty.")
            name = input("Enter Full Name: ").strip()

        age = get_valid_age()
        census_users.append([name, age])

        more = input("Add another initial record? (y/n): ").strip().lower()
        if more != "y":
            break

    display_census_list(census_users, "Initial Registered Users")

    # 2. Demonstration of append()
    print("\n" + "=" * 50)
    print("[Step 2] Demonstrating append() Method:")
    app_name = input("Enter Full Name to append(): ").strip()
    app_age = get_valid_age()
    census_users.append([app_name, app_age])
    display_census_list(census_users, "List After append()")

    # 3. Demonstration of insert()
    print("\n" + "=" * 50)
    print("[Step 3] Demonstrating insert() Method:")
    ins_name = input("Enter Full Name to insert(): ").strip()
    ins_age = get_valid_age()
    while True:
        try:
            ins_pos = int(input(f"Enter insertion index (0 to {len(census_users)}): "))
            if 0 <= ins_pos <= len(census_users):
                census_users.insert(ins_pos, [ins_name, ins_age])
                break
            print(f"Invalid index! Choose between 0 and {len(census_users)}.")
        except ValueError:
            print("Invalid input. Enter an integer index.")
    display_census_list(census_users, f"List After insert() at position {ins_pos}")

    # 4. Demonstration of remove()
    print("\n" + "=" * 50)
    print("[Step 4] Demonstrating remove() Method:")
    rem_name = input("Enter the Full Name to remove: ").strip()
    matched_item = None
    for record in census_users:
        if record[0].lower() == rem_name.lower():
            matched_item = record
            break

    if matched_item:
        census_users.remove(matched_item)
        print(f"Success: Record '{matched_item[0]}' removed using remove().")
    else:
        print(f"Notice: '{rem_name}' not found in list.")
    display_census_list(census_users, "List After remove()")

    # 5. Demonstration of del
    print("\n" + "=" * 50)
    print("[Step 5] Demonstrating del Statement:")
    if census_users:
        while True:
            try:
                del_idx = int(input(f"Enter index to delete using 'del' (0 to {len(census_users)-1}): "))
                if 0 <= del_idx < len(census_users):
                    deleted_val = census_users[del_idx]
                    del census_users[del_idx]
                    print(f"Success: Deleted index {del_idx} ({deleted_val}) using del.")
                    break
                print("Index out of bounds.")
            except ValueError:
                print("Enter a valid integer index.")
    display_census_list(census_users, "List After del Statement")

    # 6. Finding by Name and Age
    print("\n" + "=" * 50)
    print("[Step 6] Searching by Name and Age Criteria:")
    s_name = input("Enter Name to search: ").strip()
    found_by_name = [u for u in census_users if u[0].lower() == s_name.lower()]
    print(f"Search Result (Name='{s_name}'): {found_by_name if found_by_name else 'Not found'}")

    s_age = get_valid_age("Enter Age to search: ")
    found_by_age = [u for u in census_users if u[1] == s_age]
    print(f"Search Result (Age={s_age}): {found_by_age if found_by_age else 'Not found'}")

    # 7. Sorting (Ascending & Descending by Name & Age)
    print("\n" + "=" * 50)
    print("[Step 7] Demonstrating Sorting:")

    sort_name_asc = sorted(census_users, key=lambda x: x[0].lower())
    display_census_list(sort_name_asc, "Sorted by Name (Ascending)")

    sort_name_desc = sorted(census_users, key=lambda x: x[0].lower(), reverse=True)
    display_census_list(sort_name_desc, "Sorted by Name (Descending)")

    sort_age_asc = sorted(census_users, key=lambda x: x[1])
    display_census_list(sort_age_asc, "Sorted by Age (Ascending)")

    sort_age_desc = sorted(census_users, key=lambda x: x[1], reverse=True)
    display_census_list(sort_age_desc, "Sorted by Age (Descending)")

    print("\n" + "=" * 65)
    print("Census Data Collection Script Executed Successfully.")
    print("=" * 65)


if __name__ == "__main__":
    main()
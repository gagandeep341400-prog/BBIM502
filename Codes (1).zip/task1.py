# BBIM502 - Assessment 1
# Task 1 - Variables & Data types
# Program to Calculate Momentum: p = m * v

def get_positive_float(prompt):
    """Function to validate positive floating-point user input."""
    while True:
        try:
            value = float(input(prompt))
            if value <= 0:
                print("Error: Value must be a positive number greater than 0.\n")
            else:
                return value
        except ValueError:
            print("Error: Invalid input. Please enter a valid numeric value.\n")

def main():
    print("=" * 50)
    print("         MOMENTUM CALCULATOR (p = m * v)")
    print("=" * 50)

    # 1. Accept Mass (m) in kg with validation
    m = get_positive_float("Enter object mass 'm' (in kg): ")

    # 2. Accept Velocity (v) in m/s with validation
    v = get_positive_float("Enter object velocity 'v' (in m/s): ")

    # 3. Calculate Momentum (p)
    p = m * v

    # 4. Output results clearly
    print("\n" + "-" * 50)
    print("                 RESULTS")
    print("-" * 50)
    print(f"Mass (m)         : {m:.2f} kg (Type: {type(m).__name__})")
    print(f"Velocity (v)     : {v:.2f} m/s (Type: {type(v).__name__})")
    print(f"Momentum (p)     : {p:.2f} kg·m/s (Type: {type(p).__name__})")
    print("=" * 50)

if __name__ == "__main__":
    main()
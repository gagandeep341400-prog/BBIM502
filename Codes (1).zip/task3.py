# BBIM502 - Assessment 1
# Task 3 - Comparison Operators
# Electricity Charges Comparison System


def get_positive_kwh(customer_label):
    """Validates user input for kWh power consumption."""
    while True:
        try:
            val = float(input(f"Enter {customer_label} consumption in kWh: "))
            if val >= 0:
                return val
            print("Error: Consumption cannot be negative.\n")
        except ValueError:
            print("Error: Invalid input. Enter a numeric value.\n")


def calculate_and_compare(customer_name, units):
    """Calculates both plans and uses comparison operators to recommend the best option."""
    billing_days = 30
    levy_rate = 0.13 / 100.0  # $0.0013 per kWh

    # Low User Plan: 60 cents/day + 23.8 cents/kWh + levy
    low_daily = 0.60
    low_energy_rate = 23.8 / 100.0
    low_total = (billing_days * low_daily) + (units * low_energy_rate) + (units * levy_rate)

    # Standard User Plan: $1.891/day + 18 cents/kWh + levy
    std_daily = 1.891
    std_energy_rate = 18.0 / 100.0
    std_total = (billing_days * std_daily) + (units * std_energy_rate) + (units * levy_rate)

    # Determine Customer Tier using Comparison Operators
    if units <= 300:
        tier_str = "Customer 1 Tier (<= 300 kWh)"
    elif units > 300 and units <= 500:
        tier_str = "Customer 2 Tier (> 300 and <= 500 kWh)"
    else:
        tier_str = "Customer 3 Tier (> 500 kWh)"

    # Determine Economical Recommendation using Comparison Operators
    if low_total < std_total:
        recommendation = "Low User Plan"
        savings = std_total - low_total
    elif std_total < low_total:
        recommendation = "Standard User Plan"
        savings = low_total - std_total
    else:
        recommendation = "Both Plans Cost Exactly the Same"
        savings = 0.0

    print("\n" + "-" * 60)
    print(f"ANALYSIS FOR: {customer_name}")
    print("-" * 60)
    print(f"Usage Category   : {tier_str}")
    print(f"Electricity Used : {units:.2f} kWh across {billing_days} days")
    print(f"Low User Total   : ${low_total:.2f}")
    print(f"Std User Total   : ${std_total:.2f}")
    print(f"Recommendation   : >>> {recommendation} <<<")
    if savings > 0:
        print(f"Estimated Savings: ${savings:.2f}")


def main():
    print("=" * 60)
    print("      ELECTRICITY CHARGES COMPARISON SYSTEM (30 DAYS)")
    print("=" * 60)

    # Accept 3 customer consumptions
    c1_usage = get_positive_kwh("Customer 1 (e.g., <=300 kWh)")
    c2_usage = get_positive_kwh("Customer 2 (e.g., 301-500 kWh)")
    c3_usage = get_positive_kwh("Customer 3 (e.g., >500 kWh)")

    calculate_and_compare("Customer 1", c1_usage)
    calculate_and_compare("Customer 2", c2_usage)
    calculate_and_compare("Customer 3", c3_usage)

    print("\n" + "=" * 60)
    print("Comparison complete for all customers.")
    print("=" * 60)


if __name__ == "__main__":
    main()
# BBIM502 - Assessment 1
# Task 6 - Function with Arrays
# Fibonacci Sequence in Honeybees Breeding
# Student Name : Gagandip Singh
# Student ID   : 850008390
# Function Name: hbfSeqFunc390 (hbfSeqFunc + last 3 digits of Student ID)


def hbfSeqFunc390(n):
    """
    Generates and returns the Fibonacci sequence up to N elements
    using a list/array data structure.
    Honeybee Breeding Context:
      - A male drone has 1 parent (mother: 1).
      - A female worker/queen has 2 parents (mother & father: 2).
      - Grandparents = 3, Great-grandparents = 5, etc.
    """
    if n <= 0:
        return []

    # Array data structure to store the sequence
    fib_array = []

    for i in range(n):
        if i == 0:
            fib_array.append(0)
        elif i == 1:
            fib_array.append(1)
        else:
            fib_array.append(fib_array[i - 1] + fib_array[i - 2])

    return fib_array


def main():
    print("=" * 65)
    print("      FIBONACCI SEQUENCE IN HONEYBEE BREEDING MODEL")
    print("=" * 65)
    print("Context: Male bees have 1 parent; Female bees have 2 parents.")
    print("This ancestral genealogy directly generates the Fibonacci series.")
    print("-" * 65)

    # Input validation
    while True:
        try:
            n = int(input("Enter number of terms 'N' (positive integer): "))
            if n > 0:
                break
            print("Error: N must be greater than 0.\n")
        except ValueError:
            print("Error: Please enter a valid whole number.\n")

    # Call function
    sequence = hbfSeqFunc390(n)

    # Output requirements: First N numbers & the Nth number
    print("\n" + "=" * 65)
    print(f"First {n} Fibonacci Numbers:")
    print(" ".join(map(str, sequence)))
    print("-" * 65)
    print(f"The {n}th Fibonacci Number is: {sequence[n - 1]}")
    print("=" * 65)


if __name__ == "__main__":
    main()
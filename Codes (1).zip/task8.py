# BBIM502 - Assessment 1
# Task 8 - Data Structures: Dictionary
# Game Inventory System


# Function 1: Displays all keys and values using items() — takes inventory as parameter
def display_inventory_all(inventory_dict):
    """Displays all keys and values in the dictionary using items()."""
    print("\n[Function 1] All Inventory Items (keys & values using .items()):")
    print("-" * 40)
    for key, val in inventory_dict.items():
        print(f" Item: {key:<12} | Count: {val}")


# Function 2: Displays bullet value using get() — takes inventory as parameter
def display_bullet_count(inventory_dict):
    """Retrieves and displays the 'bullet' count using .get()."""
    print("\n[Function 2] Specific Item Query (using .get()):")
    print("-" * 40)
    bullet_val = inventory_dict.get("bullet", "Item not found")
    print(f" Quantity of 'bullet': {bullet_val}")


# Function 3: Displays all keys using keys() — takes inventory as parameter
def display_inventory_keys(inventory_dict):
    """Displays all dictionary keys using .keys()."""
    print("\n[Function 3] All Inventory Keys (using .keys()):")
    print("-" * 40)
    all_keys = list(inventory_dict.keys())
    print("Keys List:", all_keys)
    for k in inventory_dict.keys():
        print(f" • Key: {k}")


# Function 4: Displays all values using values() — takes inventory as parameter
def display_inventory_values(inventory_dict):
    """Displays all dictionary values using .values()."""
    print("\n[Function 4] All Inventory Values (using .values()):")
    print("-" * 40)
    all_values = list(inventory_dict.values())
    print("Values List:", all_values)
    for v in inventory_dict.values():
        print(f" • Value: {v}")


def main():
    print("=" * 55)
    print("         GAME INVENTORY DICTIONARY SYSTEM")
    print("=" * 55)

    # Initial dictionary required by brief
    player_inventory = {
        "bow": 2,
        "arrow": 20,
        "gun": 3,
        "bullet": 100,
        "rope": 1,
        "torch": 4,
        "jacket": 2
    }

    # Pass dictionary explicitly as argument to all 4 functions
    display_inventory_all(player_inventory)
    display_bullet_count(player_inventory)
    display_inventory_keys(player_inventory)
    display_inventory_values(player_inventory)

    print("\n" + "=" * 55)
    print("Inventory operations completed successfully.")
    print("=" * 55)


if __name__ == "__main__":
    main()
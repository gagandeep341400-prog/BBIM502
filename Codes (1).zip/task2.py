# BBIM502 - Assessment 1
# Task 2 - Arithmetic Operators
# Parking Charges Calculator

import math

def get_valid_time(prompt):
    """Validates 24-hour format time input between 0.00 and 24.00."""
    while True:
        try:
            time_val = float(input(prompt))
            if 0.0 <= time_val <= 24.0:
                return time_val
            else:
                print("Error: Time must be between 0.00 (00:00) and 24.00 (24:00).\n")
        except ValueError:
            print("Error: Please enter time in numeric decimal format (e.g. 9.5 for 9:30 AM).\n")

def calculate_casual_rate(duration_minutes, duration_hours):
    """Calculates Casual rate based on minutes/hours parked."""
    if duration_minutes <= 20:
        return 3.00
    elif duration_minutes <= 60:
        return 15.00
    else:
        # Per half hour thereafter ($7.50 per half-hour), capped at $55.00
        extra_hours = duration_hours - 1.0
        half_hours = math.ceil(extra_hours * 2)
        total = 15.00 + (half_hours * 7.50)
        return min(total, 55.00)

def main():
    print("=" * 60)
    print("        PARKING CHARGES CALCULATOR SYSTEM")
    print("=" * 60)

    # Validate Lost Ticket
    while True:
        lost_ticket = input("Did you lose your ticket? (yes/no): ").strip().lower()
        if lost_ticket in ["yes", "y"]:
            print("\n" + "=" * 50)
            print("PARKING RECEIPT")
            print("Status       : Lost Ticket")
            print("Total Charge : $75.00")
            print("=" * 50)
            return
        elif lost_ticket in ["no", "n"]:
            break
        else:
            print("Please answer 'yes' or 'no'.\n")

    # Validate Parking Category
    print("\nSelect Parking Category:")
    print("1. Casual Parking (Mon - Fri)")
    print("2. Early Bird (Mon - Fri | In: 5am-10am, Out: 2pm-8pm)")
    print("3. Night Parking (In: After 4pm | Valid until 6am)")
    print("4. Weekend Parking (Sat - Sun | Valid until 6am)")

    while True:
        try:
            category = int(input("Enter choice (1-4): "))
            if 1 <= category <= 4:
                break
            print("Invalid category. Enter 1, 2, 3, or 4.\n")
        except ValueError:
            print("Invalid input. Please enter a whole number (1-4).\n")

    # Validate Day of Week
    valid_days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    while True:
        day = input("Enter day of the week: ").strip().lower()
        if day in valid_days:
            break
        print("Invalid day entered. Please check spelling.\n")

    # Validate Entry and Exit Times
    print("\nNote: Enter time in 24-hr decimal format (e.g. 9.5 = 9:30 AM, 17.0 = 5:00 PM)")
    in_time = get_valid_time("Enter In-Time  (0.0 - 24.0): ")
    out_time = get_valid_time("Enter Out-Time (0.0 - 24.0): ")

    # Calculate Duration
    if out_time >= in_time:
        duration_hours = out_time - in_time
    else:
        # Crosses midnight
        duration_hours = (24.0 - in_time) + out_time

    duration_minutes = duration_hours * 60.0
    charge = 0.0

    # Apply Category Specific Rules
    if category == 1:  # Casual
        if day in ["saturday", "sunday"]:
            print("\nNotice: Casual parking table applies to Monday - Friday. Applying standard casual rate calculation.")
        charge = calculate_casual_rate(duration_minutes, duration_hours)

    elif category == 2:  # Early Bird
        is_weekday = day in ["monday", "tuesday", "wednesday", "thursday", "friday"]
        valid_in = 5.0 <= in_time <= 10.0
        valid_out = 14.0 <= out_time <= 20.0

        if is_weekday and valid_in and valid_out:
            charge = 15.00
        else:
            print("\nNotice: Early Bird conditions not fully met (Entry 5-10 AM, Exit 2-8 PM Mon-Fri).")
            print("Defaulting to Casual Rate calculation for duration.")
            charge = calculate_casual_rate(duration_minutes, duration_hours)

    elif category == 3:  # Night Parking
        if in_time >= 16.0 or in_time <= 6.0:
            if duration_minutes <= 20:
                charge = 3.00
            else:
                charge = 15.00
        else:
            print("\nNotice: Night parking entered before 4:00 PM. Defaulting to Casual rate.")
            charge = calculate_casual_rate(duration_minutes, duration_hours)

    elif category == 4:  # Weekend Parking
        if day in ["saturday", "sunday"]:
            if duration_minutes <= 20:
                charge = 3.00
            else:
                charge = 15.00
        else:
            print("\nNotice: Weekend parking selected on a weekday. Defaulting to Casual rate.")
            charge = calculate_casual_rate(duration_minutes, duration_hours)

    # Print Detailed Receipt
    print("\n" + "=" * 50)
    print("                 PARKING RECEIPT")
    print("=" * 50)
    print(f"Day of Week      : {day.capitalize()}")
    print(f"In-Time          : {in_time:.2f}")
    print(f"Out-Time         : {out_time:.2f}")
    print(f"Total Duration   : {duration_hours:.2f} hrs ({duration_minutes:.0f} mins)")
    print(f"Total Amount Due : ${charge:.2f}")
    print("=" * 50)

if __name__ == "__main__":
    main()
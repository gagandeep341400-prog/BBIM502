# BBIM502 - Assessment 1
# Task 5 - Simple Function with Parameters
# Temperature Conversion System


def convert_temperature(temperature, source, target):
    """
    Converts temperature between Celsius, Fahrenheit, and Kelvin.
    Takes 3 parameters: temperature (float), source (str), target (str).
    """
    su = source.strip().capitalize()
    tu = target.strip().capitalize()

    # If same units
    if su == tu:
        return temperature

    # Convert source unit to Celsius baseline
    if su == "Celsius":
        celsius_val = temperature
    elif su == "Fahrenheit":
        celsius_val = (temperature - 32.0) * (5.0 / 9.0)
    elif su == "Kelvin":
        celsius_val = temperature - 273.15
    else:
        raise ValueError(f"Unknown source unit: {source}")

    # Convert Celsius baseline to target unit
    if tu == "Celsius":
        return celsius_val
    elif tu == "Fahrenheit":
        return (celsius_val * (9.0 / 5.0)) + 32.0
    elif tu == "Kelvin":
        return celsius_val + 273.15
    else:
        raise ValueError(f"Unknown target unit: {target}")


def get_valid_unit(prompt):
    """Validates temperature scale name."""
    valid_units = ["Celsius", "Fahrenheit", "Kelvin"]
    while True:
        unit = input(prompt).strip().capitalize()
        if unit in valid_units:
            return unit
        print(f"Invalid unit! Please enter one of: {', '.join(valid_units)}\n")


def main():
    print("=" * 55)
    print("       TEMPERATURE CONVERSION SYSTEM")
    print("=" * 55)

    # Validated user inputs
    while True:
        try:
            temp_input = float(input("Enter the temperature value: "))
            break
        except ValueError:
            print("Error: Please enter a valid numeric value.\n")

    source_unit = get_valid_unit("Enter source unit (Celsius / Fahrenheit / Kelvin): ")
    target_unit = get_valid_unit("Enter target unit (Celsius / Fahrenheit / Kelvin): ")

    # Call user-defined function with 3 parameters
    result = convert_temperature(temp_input, source_unit, target_unit)

    print("\n" + "=" * 55)
    print("                  RESULT")
    print("=" * 55)
    print(f"Source Temperature : {temp_input:.2f} °{source_unit}")
    print(f"Target Converted   : {result:.2f} °{target_unit}")
    print("=" * 55)


if __name__ == "__main__":
    main()
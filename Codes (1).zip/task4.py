# BBIM502 - Assessment 1
# Task 4 - Logical Operators
# Employee Weekly Pay Calculator


def get_validated_number(prompt):
    """Helper function to validate positive numeric input."""
    while True:
        try:
            val = float(input(prompt))
            if val >= 0:
                return val
            print("Error: Value cannot be negative. Please try again.\n")
        except ValueError:
            print("Error: Please enter a valid numeric value.\n")


def main():
    print("=" * 55)
    print("        EMPLOYEE WEEKLY PAY CALCULATOR")
    print("=" * 55)

    # 1. User inputs with validation
    hourly_wage = get_validated_number("Enter hourly wage ($): ")
    regular_hours = get_validated_number("Enter total regular hours worked: ")
    overtime_hours = get_validated_number("Enter extra overtime hours worked: ")

    # 2. Regular Pay Calculation
    regular_pay = hourly_wage * regular_hours

    # 3. Using Logical Operators (and / or / not) for Decision Making
    has_worked_overtime = (overtime_hours > 0) and not (hourly_wage <= 0)

    if has_worked_overtime:
        overtime_pay = overtime_hours * (1.5 * hourly_wage)
        overtime_status = "Yes"
    else:
        overtime_pay = 0.0
        overtime_status = "No"

    # 4. Total Weekly Pay
    total_weekly_pay = regular_pay + overtime_pay

    # 5. Summary Display
    print("\n" + "=" * 55)
    print("             WEEKLY PAY STATEMENT")
    print("=" * 55)
    print(f"Hourly Wage Rate      : ${hourly_wage:.2f}/hr")
    print(f"Regular Hours Worked  : {regular_hours:.2f} hrs")
    print(f"Overtime Hours Worked : {overtime_hours:.2f} hrs")
    print(f"Overtime Applicable?  : {overtime_status}")
    print("-" * 55)
    print(f"Regular Pay Amount    : ${regular_pay:.2f}")
    print(f"Overtime Pay Amount   : ${overtime_pay:.2f}")
    print("-" * 55)
    print(f"TOTAL GROSS PAY       : ${total_weekly_pay:.2f}")
    print("=" * 55)


if __name__ == "__main__":
    main()